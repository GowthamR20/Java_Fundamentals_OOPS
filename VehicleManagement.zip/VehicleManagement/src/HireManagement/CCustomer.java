package HireManagement;

import java.io.Serializable;

public class CCustomer extends Customer implements Serializable {
	private double rate;
	private String customerId;
	private String cusName;

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public CCustomer(String customerId, String cusName, double rate) {
		super(customerId, cusName, "");
		setRate(rate);
		setCustomerId(customerId);
		setCusName(cusName);
	}

	@Override
	public double getDiscount(double amount) {
		amount -= amount * (getRate() / 100);
		return amount;
	}

	public String toString() {
		return this.getCustomerId() + "\t" + this.getCusName() + "\t" + this.getRate();

	}
	public void print() {
		System.out.println("Customer Id:" + this.getCustomerId() + "\tCustomer Name:" + this.getCusName()
				+ "\tRate:" + this.getRate());
	}
	@Override
	public void calculateMilage(int a) {
		// TODO Auto-generated method stub

	}
}