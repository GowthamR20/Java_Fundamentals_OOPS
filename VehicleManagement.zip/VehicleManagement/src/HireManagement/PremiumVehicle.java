package HireManagement;

public class PremiumVehicle extends Vehicle {

	private int freeMileageAllow;
	private int serviceLength;
	private int odometerReadingLS;

	public int getFreeMileageAllow() {
		return freeMileageAllow;
	}

	public void setFreeMileageAllow(int freeMilageAllow) {
		this.freeMileageAllow = freeMilageAllow;
	}

	public int getServiceLength() {
		return serviceLength;
	}

	public void setServiceLength(int serviceLength) {
		this.serviceLength = serviceLength;
	}

	public int getOdometerReadingLS() {
		return odometerReadingLS;
	}

	public void setOdometerReadingLS(int odometerReadingLS) {
		this.odometerReadingLS = odometerReadingLS;
	}

	public PremiumVehicle(String vehicleId, String description, double dailyRate, int odometerReading,
			int freeMileageAllow, int serviceLength, int odometerLS) {
		super(vehicleId, description, dailyRate, odometerReading);
		this.freeMileageAllow = freeMileageAllow;
		this.serviceLength = serviceLength;
		this.odometerReadingLS = odometerLS;
	}

	public boolean hire(String hirerId) throws StatusException {
		if (getOdometerReading() > getServiceLength() + getOdometerReadingLS()) {
			System.out.println("Vehicle Cannot be hired");
			return false;
		} else {
			super.hire(hirerId);
			return true;
		}
	}

	public double hireComplete(int odoReading) throws StatusException, OdometerException {
		double hireCharge = super.hireComplete(odoReading);
		hireCharge = hireCharge + ((odoReading - getOdometerReadingLS())
				- (getFreeMileageAllow() * DateTime.diffDays(getDt2(), getDt1()) * 0.1));
		setOdometerReadingLS(odoReading);
		return hireCharge;
	}

	public void service() {
		super.service();
	}

	public void serviceComplete(int odoReading) throws StatusException, OdometerException {
		super.serviceComplete(odoReading);
		if (getOdometerReading() < odoReading)
			setOdometerReadingLS(odoReading);
	}

	public void print() {
		super.print();
		System.out.println(" Milage Allowance:" + getFreeMileageAllow() + "\t" + "Last Service:"
				+ getOdometerReadingLS() + "\t" + "Service Duration:" + getServiceLength());
	}

	public String toString() {
		return super.toString() + "\t" + getFreeMileageAllow() + "\t" + getOdometerReadingLS() + "\t"
				+ getServiceLength();
	}

}
