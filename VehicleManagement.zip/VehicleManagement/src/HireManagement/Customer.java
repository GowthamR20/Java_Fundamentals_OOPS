package HireManagement;

import java.io.Serializable;

public abstract class Customer implements Serializable {
	private String Id;
	private String customerName;
	private static String customerPhone;

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public static String getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}

	public Customer(String id, String customerName, String customerPhone) {
		setId(id);
		setCustomerName(customerName);
		setCustomerPhone(customerPhone);
	}

	public abstract double getDiscount(double amount);

	public abstract void print();

	public abstract String toString();

	public abstract void calculateMilage(int a);

}
