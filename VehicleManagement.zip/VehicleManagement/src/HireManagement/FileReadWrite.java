package HireManagement;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class FileReadWrite {
	private static File f;

	public static void saveVehicleDetails(String fileName, ArrayList<Vehicle> vehList) throws IOException {
		FileOutputStream file = new FileOutputStream(fileName);
		ObjectOutputStream out = new ObjectOutputStream(file);
		out.writeObject(vehList);
		out.close();
		file.close();
	}

	public static ArrayList<Vehicle> readVechDetails(String fileName) throws IOException, ClassNotFoundException {
		f = new File(fileName);
		ArrayList<Vehicle> vehList = new ArrayList<Vehicle>();
		if (f.exists()) {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
			vehList = (ArrayList<Vehicle>) in.readObject();
			in.close();
		} else {
		}

		return vehList;
	}

	public static void saveCustomerDetails(String fileName, ArrayList<Customer> cusList) throws IOException {
		FileOutputStream file = new FileOutputStream(fileName);
		ObjectOutputStream out = new ObjectOutputStream(file);
		out.writeObject(cusList);
		out.close();
		file.close();
	}

	public static ArrayList<Customer> readCusDetails(String fileName) throws IOException, ClassNotFoundException {
		f = new File(fileName);
		ArrayList<Customer> cusList = new ArrayList<Customer>();
		if (f.exists()) {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
			cusList = (ArrayList<Customer>) in.readObject();
			in.close();
		} else {
		
		}
		return cusList;
	}

	public static void writeRentReport(String fileName, ArrayList<String> rentReportList) throws IOException {
		FileOutputStream file = new FileOutputStream(fileName);
		ObjectOutputStream out = new ObjectOutputStream(file);
		out.writeObject(rentReportList);
		out.close();
		file.close();
	}

	public static ArrayList<String> readRentReport(String fileName) throws IOException, ClassNotFoundException {
		f = new File(fileName);
		ArrayList<String> repList = new ArrayList<String>();
		if (f.exists()) {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
			repList = (ArrayList<String>) in.readObject();
			in.close();
		} else {
			System.out.println("No Report Available");
			System.out.println();
		}
		return repList;
	}

}