
package HireManagement;

public class StatusException extends Exception {

	public StatusException(String str) {
		System.out.println(str);
	}
	public void throwError(String str) {
		System.out.println(str);
	}

}

