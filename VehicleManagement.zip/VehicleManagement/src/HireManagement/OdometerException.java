package HireManagement;

public class OdometerException extends Exception {
	public OdometerException(String str) {
		System.out.println(str);
	}

}
