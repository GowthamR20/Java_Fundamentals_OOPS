package HireManagement;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class ManageHire implements Serializable {
	static Scanner scan = new Scanner(System.in);
	private static ArrayList<Vehicle> vehList = new ArrayList<Vehicle>();
	private static Vehicle vehs = null;

	private static String vehicleType;
	private static String vehicleId;
	private static String vehicleDescription;
	private static double dailyRate;
	private static int vehicleOdometerReading;
	private static int dailyMileage;
	private static int serviceLength;
	private static int Lastservice;
	private static String hirerId;
	private static String vehFileName = "vehicle.txt";

	private static ArrayList<Customer> cusList = new ArrayList<Customer>();
	private static Customer cust = null;
	private static String customerType;
	private static String customerId;
	private static String customerName;
	private static String customerPhone;
	private static double rate;
	public static int mileage;
	private static String cusFileName = "customer.txt";

	private static ArrayList<String> rentReportList = new ArrayList<String>();
	static FileReadWrite frw = new FileReadWrite();
	private static String reportFile = "rentReport.txt";

	private static boolean validation = false;
	private static String choice;

	// this function is used to get a vehicle ID and return the index from the list.
	public static int getUserVehicleID() {
		System.out.print("Enter the vehicle ID:");
		String Id = scan.next();
		boolean vehiclePresent = false;
		int i;
		for (i = 0; i < vehList.size(); i++) {
			if (vehList.get(i).getVehicleId().equalsIgnoreCase(Id)) {
				vehiclePresent = true;
				break;
			} else {
				vehiclePresent = false;
			}
		}
		if (vehiclePresent == true)
			return i;
		else
			System.out.println("Vehicle ID not found. Check Vehicle Record");
		return -1;
	}

	// this function is used to get a vehicle ID and return the index from the list.
	public static int getUserCustomerID() {
		System.out.print("Enter the Customer ID:");
		String Id = scan.next();
		boolean customerPresent = false;
		int i;
		// System.out.println(cusList.get(0).getId());
		for (i = 0; i < cusList.size(); i++) {
			if (cusList.get(i).getId().equalsIgnoreCase(Id)) {
				customerPresent = true;
				break;
			} else {
				customerPresent = false;
			}
		}
		if (customerPresent == true)
			return i;
		else
			System.out.println("Customer ID not found. Check Customer Record");
		return -1;
	}

	// this function is used to add Vehicle/ Premium and save it in a file
	public static void addVehicle() throws IOException {
		do {
			// Get and validate vehicle Type
			do {
				System.out.print("Enter Vehicle Type:");
				vehicleType = scan.next();

				if (vehicleType.equals("Vehicle") || vehicleType.equals("Premium")) {
					validation = false;
				} else {
					System.out.println("Invalid Vehicle Type.Try again....");
					validation = true;
				}
			} while (validation);
			// Get and validate vehicle Type End

			// get and validate vehicle ID
			do {
				System.out.print("Vehicle ID:");
				vehicleId = scan.next();
				if (vehicleId.length() == 6) {
					validation = false;
				} else {
					System.out.println("Invalid Vehicle ID. Try again.....");
					validation = true;
				}

				if (!vehList.isEmpty()) {
					for (int i = 0; i < vehList.size(); i++) {
						if (vehList.get(i).getVehicleId().equals(vehicleId)) {
							System.out.println("Duplicate ID is found. Try Again....");
							validation = true;
						}
					}
				}
			} while (validation);
			// get and validate vehicle ID End

			System.out.print("Vehicle Description:");
			vehicleDescription = scan.next();
			System.out.print("Vehicle Daily Rate:");
			dailyRate = scan.nextDouble();
			System.out.print("Vehicle Odometer Reading:");
			vehicleOdometerReading = scan.nextInt();

			if (vehicleType.equals("Premium")) {
				System.out.print("Daily Mileage Allowance:");
				dailyMileage = scan.nextInt();
				System.out.print("Service Length:");
				serviceLength = scan.nextInt();
				System.out.print("Odometer Reading after last service:");
				Lastservice = scan.nextInt();
				System.out.println("***** CREATING PREMIUM VEHICLE OBJECT *****");
				vehs = new PremiumVehicle(vehicleId, vehicleDescription, dailyRate, vehicleOdometerReading,
						dailyMileage, serviceLength, Lastservice);
			} else {
				System.out.println("***** CREATING VEHICLE OBJECT *****");
				vehs = new Vehicle(vehicleId, vehicleDescription, dailyRate, vehicleOdometerReading);
			}
			System.out.println("***** ADDING TO THE VEHICL LIST *****");
			vehList.add(vehs);

			System.out.print("Add More Vehicle?:");
			choice = scan.next();
		} while (choice.toLowerCase().charAt(0) == 'y');
		System.out.println("***** ADDING VEHICLE DETAILS TO THE FILE *****");
		FileReadWrite.saveVehicleDetails(vehFileName, vehList);
	}

	// this function is used to add ICustomer/CCustomer and save it in a file
	public static void addCustomer() throws IOException {
		do {
			do {
				System.out.print("Customer Type:");
				customerType = scan.next();
				if (customerType.equals("ICustomer") || customerType.equals("CCustomer")) {
					validation = false;
				} else {
					System.out.println("Such Customer are not allowed. Try again....");
					validation = true;
				}
			} while (validation);

			do {
				System.out.print("Customer ID:");
				customerId = scan.next();
				if (customerId.length() == 6 && customerId.startsWith("c")) {
					validation = false;
				} else {
					System.out.println("Wrong Customer ID. Try again....");
					validation = true;
				}
			} while (validation);
			System.out.print("Customer Name:");
			customerName = scan.next();
			if (customerType.equals("ICustomer")) {
				System.out.print("Customer Phone Number:");
				customerPhone = scan.next();
				System.out.print("Mileage:");
				mileage = scan.nextInt();
				System.out.println("***** CREATING ICCUSTOMER OBJECT *****");
				cust = new ICustomer(customerId, customerName, customerPhone, mileage);
			} else {
				System.out.print("Rate:");
				rate = scan.nextDouble();
				System.out.println("***** CREATING CCUSTOMER OBJECT *****");
				cust = new CCustomer(customerId, customerName, rate);
			}
			System.out.println("***** ADDING CUSTOMER DETAILS TO LIST *****");
			cusList.add(cust);

			System.out.print("Add More Customer?:");
			choice = scan.next();
		} while (choice.toLowerCase().charAt(0) == 'y');
		System.out.println("***** ADDING CUSTOMER DETAILS TO THE FILE *****");
		FileReadWrite.saveCustomerDetails(cusFileName, cusList);
	}

	public static void main(String arg[])
			throws StatusException, OdometerException, IOException, ClassNotFoundException {

		int menuOption = 0;
		do {
			System.out.println("********** Vehicle Management System **********");
			System.out.println(
					"\t\t1.\tAdd Vehicle\n\t\t2.\tDisplay Vehicles\n\t\t3.\tAdd Customer\n\t\t4.\tDisplay Customers\n\t\t5.\tHire a vehicle\n\t\t6.\tHire Complete\n\t\t7.\tService\n\t\t8.\tService Complete\n\t\t9.\tRent Report\n\t\t10.\tExit\n");
			System.out.println("\"************************************************");
			System.out.print("Choose an option:");
			menuOption = scan.nextInt();
			System.out.println("***************************************************");
			switch (menuOption) {
			case 1: {
				System.out.println("***** ADDING VEHICLE *****");
				vehList = frw.readVechDetails(vehFileName);
				for (int i = 0; i < vehList.size(); i++) {
					System.out.println(vehList.get(i));
				}
				addVehicle();
				break;
			}
			case 2: {
				vehList = frw.readVechDetails(vehFileName);
				if (vehList.isEmpty()) {
					System.out.println("No vehicle to display");
				} else {

					int upperRange = 0;
					System.out.print(
							" 'a'to enter the range to display the vehicles \n 'b' to display all the available vehicles:");
					String c = scan.next();
					switch (c.charAt(0)) {
					case 'a': {
						System.out.print("From:");
						int lowerRange = scan.nextInt();
						do {
							System.out.print("To:");
							upperRange = scan.nextInt();
							if (upperRange > lowerRange) {
								validation = false;
							} else {
								System.out.println("Enter Upper range greater then the Lower range");
								validation = true;
							}
						} while (validation);
						for (int i = 0; i < vehList.size(); i++) {
							if (vehList.get(i).getDailyRate() >= lowerRange
									&& vehList.get(i).getDailyRate() <= upperRange) {
								vehList.get(i).print();
							} else {
								System.out.println("OOPS! No Vehicle in the specified range");
							}
						}
						break;
					}
					case 'b': {
						System.out.println("***** Displaying all available vehicles *****");
						for (int i = 0; i < vehList.size(); i++) {
							vehList.get(i).print();
						}
						break;
					}
					}
				}
				break;
			}
			case 3: {
				System.out.println("***** ADDING CUSTOMER *****");
				cusList = frw.readCusDetails(cusFileName);
				for (int i = 0; i < cusList.size(); i++) {
					System.out.println(cusList.get(i));
				}
				addCustomer();
				break;
			}
			case 4: {
				System.out.println("***** Displaying all Customers *****");
				cusList = frw.readCusDetails(cusFileName);
				if (cusList.isEmpty()) {
					System.out.println("No Customer Details to display");
				} else {
					for (int i = 0; i < cusList.size(); i++) {
						cusList.get(i).print();
					}
				}
				break;
			}
			case 5: {
				vehList = frw.readVechDetails(vehFileName);
				cusList = frw.readCusDetails(cusFileName);
				if (!(vehList.isEmpty()) || !(cusList.isEmpty())) {
					System.out.println("****** HIRING A VEHICLE *****");
					int vIndex = getUserVehicleID();
					int cIndex = getUserCustomerID();
					boolean hire = true;
					if (vIndex != -1 && cIndex != -1) {
						/*
						 * loop through the list of vehicles and returns the customer type and the
						 * vehicle status with which we will decide if the vehicle or the customer can
						 * hire.
						 */
						for (int j = 0; j < vehList.size(); j++) {
							if (cusList.get(cIndex).getId().equals(vehList.get(j).getHirerId())) {
								if (cusList.get(cIndex) instanceof ICustomer) {
									if (vehList.get(j).getStatus() == 'H') {
										System.out.println("ICustomer cannot hire more then one vehicle.");
										hire = false;
										break;
									}
								} else if (cusList.get(cIndex) instanceof CCustomer) {
									if (vehList.get(vIndex).getStatus() == 'H') {
										System.out.println("Vehicle Already hired by another customer.");
										hire = false;
										break;
									}
								}
							}
						}
						if (hire) {
							if (vehList.get(vIndex).hire(cusList.get(cIndex).getId())) {
								frw.saveVehicleDetails(vehFileName, vehList);
							}
						}
					}

				} else {
					System.out.println("No Vehicle/Customer");
				}
			}
				break;

			case 6: {
				System.out.println("***** Hire Complete *****");
				vehList = frw.readVechDetails(vehFileName);
				cusList = frw.readCusDetails(cusFileName);
				double charge = 0.0;
				int cid = 0;
				int vIndex = getUserVehicleID();
				if (vIndex != -1) {
					System.out.print("Enter odometer Reading:");
					int odo = scan.nextInt();
					if (vehList.get(vIndex).getStatus() == 'H') {
						charge = vehList.get(vIndex).hireComplete(odo);
						if (charge > -1) {
							for (int i = 0; i < cusList.size(); i++) {

								if (cusList.get(i).getId().equals(vehList.get(vIndex).getHirerId())) {
									// Checks if the customer instance is ICustomer and update the customers milage
									// reading
									cid++;
									if (cusList.get(i) instanceof ICustomer) {
										cusList.get(i)
												.calculateMilage(vehList.get(vIndex).getOdometerReadingAfterHire());
									}
									charge = cusList.get(i).getDiscount(charge);
								}

							}
							String rentDetail = vehList.get(vIndex).getVehicleId() + "\thired by "
									+ cusList.get(cid).getId() + "\tfrom " + vehList.get(vIndex).getDt1() + " to "
									+ vehList.get(vIndex).getDt2() + "\tat "
									+ (charge + vehList.get(vIndex).getCharge());

							rentReportList.add(rentDetail);
							vehList.get(vIndex).setHirerId(" ");
							vehList.get(vIndex).setDt1(null);
							System.out.println("Charge incurred:" + charge + " for hiring the vehicle id:"
									+ vehList.get(vIndex).getVehicleId() + "-->"
									+ vehList.get(vIndex).getVehicleDesc());

							FileReadWrite.saveVehicleDetails(vehFileName, vehList);
							FileReadWrite.saveCustomerDetails(cusFileName, cusList);
							FileReadWrite.writeRentReport(reportFile, rentReportList);
						}
					}
				}
				break;
			}
			case 7: {
				vehList = frw.readVechDetails(vehFileName);
				cusList = frw.readCusDetails(cusFileName);
				System.out.println("***** Service *****");
				int vIndex = getUserVehicleID();
				if (vIndex != -1) {
					vehList.get(vIndex).service();
				}
				FileReadWrite.saveVehicleDetails(vehFileName, vehList);
				break;
			}
			case 8: {
				vehList = frw.readVechDetails(vehFileName);
				cusList = frw.readCusDetails(cusFileName);
				System.out.println("***** Completing Service *****");
				int vIndex = getUserVehicleID();
				if (vIndex != -1) {
					System.out.print("Enter Odometer Reading:");
					int odo = scan.nextInt();
					vehList.get(vIndex).serviceComplete(odo);
				}
				FileReadWrite.saveVehicleDetails(vehFileName, vehList);
				break;
			}
			case 9: {
				System.out.println("***** Rent Report *****");
				rentReportList = FileReadWrite.readRentReport(reportFile);
				for (int i = 0; i < rentReportList.size(); i++) {
					System.out.println(rentReportList.get(i));
				}
			}
				break;
			case 10: {
				System.out.println("\t\t********** Thank You **********");
			}
				break;

			}
		} while (menuOption < 10);
	}
}
