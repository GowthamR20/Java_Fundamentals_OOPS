package HireManagement;

import java.io.Serializable;

public class ICustomer extends Customer implements Serializable {

	private int mileage;
	private String customerId;
	private String cusName;
	private String cusPhone;

	public int getMileage() {
		return mileage;
	}

	public void setMileage(int mileage) {
		this.mileage = mileage;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getCusPhone() {
		return cusPhone;
	}

	public void setCusPhone(String cusPhone) {
		this.cusPhone = cusPhone;
	}

	public ICustomer(String customerId, String cusName, String cusPhone, int mileage) {
		super(customerId, cusName, cusPhone);
		setMileage(mileage);
		setCustomerId(customerId);
		setCusName(cusName);
		setCusPhone(cusPhone);
	}

	@Override
	public double getDiscount(double amount) {
		if (getMileage() > 100000 && getMileage() < 200000) {
			amount -= amount * 0.1;
		} else if (getMileage() > 200000) {
			amount -= amount * 0.2;
		}
		return amount;
	}

	public String toString() {
		return this.getCustomerId() + "\t" + this.getCusName() + "\t" + this.getCusPhone() + "\t" + this.getMileage();

	}

	public void print() {
		System.out.println("Customer Id:" + this.getCustomerId() + "\tCustomer Name:" + this.getCusName()
				+ "\tPhone Number:" + this.getCusPhone() + "\tMileage:" + this.getMileage());
	}

	// method to set the customer milage after the hire is complete
	public void calculateMilage(int newMilage) {
		setMileage(getMileage() + newMilage);
	}

}
