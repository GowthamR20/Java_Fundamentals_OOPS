package HireManagement;

import java.io.Serializable;
import java.util.Scanner;

public class Vehicle implements Serializable {
	private static Scanner scan = new Scanner(System.in);
	private String vehicleId, hirerId = "", vehicleDesc;
	private double dailyRate;
	private int odometerReading;
	private char status;
	private String dateHire;
	private String timeHire;
	private String dateTimeHire = "";
	private double charge = -1;
	private int odometerReadingAfterHire = 0;

	DateTime dt1;
	DateTime dt2;

	public double getCharge() {
		return charge;
	}

	public void setCharge(double charge) {
		this.charge = charge;
	}

	public DateTime getDt1() {
		return dt1;
	}

	public void setDt1(DateTime dt1) {
		this.dt1 = dt1;
	}

	public DateTime getDt2() {
		return dt2;
	}

	public void setDt2(DateTime dt2) {
		this.dt2 = dt2;
	}

	public String getDateTimeHire() {
		return dateTimeHire;
	}

	public void setDateTimeHire(String dateTimeHire) {
		this.dateTimeHire = dateTimeHire;
	}

	// Getters and Setters
	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getHirerId() {
		return hirerId;
	}

	public void setHirerId(String hirerId) {
		this.hirerId = hirerId;
	}

	public String getVehicleDesc() {
		return vehicleDesc;
	}

	public void setVehicleDesc(String vehicleDesc) {
		this.vehicleDesc = vehicleDesc;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public int getOdometerReading() {
		return odometerReading;
	}

	public void setOdometerReading(int odometerReading) {
		this.odometerReading = odometerReading;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getDateHire() {
		return dateHire;
	}

	public void setDateHire(String dateHire) {
		this.dateHire = dateHire;
	}

	public String getTimeHire() {
		return timeHire;
	}

	public void setTimeHire(String timeHire) {
		this.timeHire = timeHire;
	}

	public int getOdometerReadingAfterHire() {
		return odometerReadingAfterHire;
	}

	public void setOdometerReadingAfterHire(int odometerReadingAfterHire) {
		this.odometerReadingAfterHire = odometerReadingAfterHire;
	}
	// Getters and setters

	public Vehicle(String vehicleId, String description, double dailyRate, int odometerReading) {
		setVehicleId(vehicleId);
		setVehicleDesc(description);
		setDailyRate(dailyRate);
		setOdometerReading(odometerReading);
		setStatus('A');
	}

	public boolean hire(String hirerId) throws StatusException {
		String str = "Vehicle cannot be hired.It is currently unavailable";
		setDt1(new DateTime());
		try {
			if (getStatus() == 'S' || getStatus() == 'H') {
				throw new StatusException(str);
			} else {
				setStatus('H');
				setHirerId(hirerId);
				System.out.printf("Vehicle %s has been hired by %s Date/Time: %s  ", getVehicleId(), getHirerId(),
						DateTime.getCurrentTime());
				return true;
			}
		} catch (StatusException se) {
		}
		return false;
	}

	public double hireComplete(int odoReading) throws StatusException, OdometerException {
		int days;
		int hours;
		int minutes;
		charge = -1.0;
		System.out.print("Enter days/hours/minutes of hired:");
		days = scan.nextInt();
		hours = scan.nextInt();
		minutes = scan.nextInt();
		DateTime.setAdvance(days, hours, minutes);
		setDt2(new DateTime());
		String str = "Vehicle not hired to complete it.";
		String oStr = "Invalid odometer Reading";
		try {
			if (getStatus() == 'H') {
				if (getOdometerReading() < odoReading) {
					System.out.println(getDt2()+"------"+getDt1());
					charge = getDailyRate() * DateTime.diffDays(getDt2(), getDt1());
					System.out.println("llllllllllllllllllllll" + charge);
					setCharge(charge);
					setStatus('A');
					this.odometerReadingAfterHire = odoReading - getOdometerReading();
					setOdometerReading(odoReading);
				} else {
					throw new OdometerException(oStr);
				}
			} else {
				System.out.println(str);
				throw new StatusException(str);
			}
		} catch (Exception e) {
		}
		return charge;
	}

	public void service() {
		String str = "Vehicle is not availale for service. Enter another option";
		try {
			if (getStatus() == 'A') {
				setStatus('S');
				System.out.println("Vehicle " + getVehicleId() + " is sent to service ");
			} else
				throw new StatusException(str);
		} catch (StatusException se) {
		}
	}

	public void serviceComplete(int odoReading) throws StatusException, OdometerException {
		String str = "Vehicle is not sent to Service to complete the service";
		String oStr = "Enter a valid odometer reading.";
		System.out.println(getOdometerReading());
		try {
			if (getStatus() == 'S') {
				setStatus('A');
				System.out.println("Vehicle " + getVehicleId() + " is returned from service");
			} else {
				throw new StatusException(str);
			}
			if (getOdometerReading() < odoReading) {
				setOdometerReading(odoReading);
			} else {
				setStatus('S');
				throw new OdometerException(oStr);
			}
		} catch (StatusException se) {
		} catch (OdometerException oe) {
		}
	}

	public void print() {
		System.out.println(" ----> ID:" + getVehicleId() + "\t" + " Description:" + getVehicleDesc() + "\t Daily Rate:"
				+ getDailyRate() + "\t" + " Status:" + getStatus() + "\t Odometer Reading:" + getOdometerReading()
				+ "\t Date/time:" + DateTime.getCurrentTime());
	}

	public String toString() {
		return getVehicleId() + "\t" + getVehicleDesc() + "\t" + getDailyRate() + "\t" + getStatus() + "\t"
				+ getOdometerReading() + "\t" + getDt1() + "\t" + getHirerId();
	}
}